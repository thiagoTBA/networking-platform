-- DropIndex
DROP INDEX "Application_email_key";

-- DropIndex
DROP INDEX "Invitation_email_key";

-- DropIndex
DROP INDEX "Member_email_key";
