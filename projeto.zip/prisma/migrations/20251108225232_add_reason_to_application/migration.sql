-- AlterTable
ALTER TABLE "Application" ADD COLUMN "reason" TEXT;
