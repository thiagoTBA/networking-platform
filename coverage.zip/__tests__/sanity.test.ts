describe("Sanity test", () => {
  it("Jest está rodando corretamente", () => {
    expect(1 + 2).toBe(3);
  });
});
