const nextConfig = {
  experimental: {
    //turbo: false,
  },
};

export default nextConfig;
